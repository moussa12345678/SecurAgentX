"""securagentx.reports — Markdown report assembly + multi-format exporter.

This package ports PentAGI's report-generation pipeline
(``frontend/src/lib/report/{report,report-pdf}.ts``) to Python:

* :mod:`securagentx.reports.markdown`  — Markdown report assembly
  (port of ``report.ts::generateReport``). Produces the canonical
  ``# {flow_emoji} {flow_id}. {flow_title}`` + TOC + H3/H4 task /
  subtask sections document.
* :mod:`securagentx.reports.pdf`       — ReportLab-based Markdown → PDF
  renderer (port of ``report-pdf.tsx``). Handles CJK font segmentation,
  emoji substitution, hyphenation disabled, and the cover/TOC/main
  page-break rule.
* :mod:`securagentx.reports.templates` — Markdown templates for the
  four canonical report types: vulnerability, executive summary,
  technical, compliance.
* :mod:`securagentx.reports.cvss`      — CVSS v3.1 base-score
  calculator (Pydantic model + score / severity functions).
* :mod:`securagentx.reports.export`    — Top-level multi-format exporter
  (``pdf`` / ``markdown`` / ``html`` / ``json``). The public entry
  point is :func:`export_report`.

The package is intentionally lazy with heavy imports: ``reportlab``,
``markdown_it``, and ``pygments`` are imported only when the matching
renderer is actually invoked, so importing :mod:`securagentx.reports`
itself is cheap and free of optional-dependency failures.
"""

from __future__ import annotations

from .cvss import (
    CIAImpact,
    CVSSResult,
    CVSSVector,
    AttackComplexity,
    AttackVector,
    PrivilegesRequired,
    Scope,
    UserInteraction,
    calculate_cvss_score,
    cvss_result,
    cvss_severity,
    format_cvss_vector,
    parse_cvss_vector,
)
from .markdown import (
    DEFAULT_STATUS_EMOJI,
    generate_anchors,
    generate_report_markdown,
    shift_markdown_headers,
    slugify_github,
    status_emoji,
)
from .templates import (
    COMPLIANCE_REPORT_TEMPLATE,
    EXECUTIVE_SUMMARY_TEMPLATE,
    TECHNICAL_REPORT_TEMPLATE,
    TEMPLATES,
    VULNERABILITY_TEMPLATE,
    get_template,
    render_template,
)

# Heavy submodules (pdf, export) are lazy-imported on first use to keep
# `import securagentx.reports` cheap. The public symbols below pull in
# only the lightweight modules (cvss, markdown, templates).

__all__ = [
    # cvss
    "CVSSVector",
    "CVSSResult",
    "AttackVector",
    "AttackComplexity",
    "PrivilegesRequired",
    "UserInteraction",
    "Scope",
    "CIAImpact",
    "calculate_cvss_score",
    "cvss_severity",
    "cvss_result",
    "parse_cvss_vector",
    "format_cvss_vector",
    # markdown
    "DEFAULT_STATUS_EMOJI",
    "status_emoji",
    "slugify_github",
    "generate_anchors",
    "shift_markdown_headers",
    "generate_report_markdown",
    # templates
    "VULNERABILITY_TEMPLATE",
    "EXECUTIVE_SUMMARY_TEMPLATE",
    "TECHNICAL_REPORT_TEMPLATE",
    "COMPLIANCE_REPORT_TEMPLATE",
    "TEMPLATES",
    "get_template",
    "render_template",
    # submodules (lazy)
    "pdf",
    "export",
]


def __getattr__(name: str):
    """Lazy-import the heavy ``pdf`` and ``export`` submodules.

    Importing ReportLab / markdown-it-py / pygments is slow and can
    fail if optional deps are missing. We defer those imports until
    the caller actually accesses :mod:`securagentx.reports.pdf` or
    :mod:`securagentx.reports.export`.

    Uses :func:`importlib.import_module` rather than ``from … import …``
    so the lookup does not re-enter this ``__getattr__`` (which would
    cause infinite recursion).
    """
    import importlib

    if name == "pdf":
        return importlib.import_module("securagentx.reports.pdf")
    if name == "export":
        return importlib.import_module("securagentx.reports.export")
    raise AttributeError(f"module 'securagentx.reports' has no attribute {name!r}")
