"""securagentx/reports/markdown.py — Markdown report assembly.

This module ports PentAGI's ``frontend/src/lib/report/report.ts`` to Python.
The original TypeScript implementation:

* Assembles a flow → tasks → subtasks Markdown document with a TOC.
* Generates anchor IDs from the rendered heading text *including the emoji*
  using ``github-slugger`` — rehype-slug (used in the frontend HTML view)
  computes the same slug from the rendered ``<h3>``/``<h4>`` element, so any
  mismatch breaks in-page anchor links.
* Shifts each task's ``input`` markdown headers down by 3 levels (H1→H4,
  H2→H5, …) so the task input — which may itself contain H1/H2 headings —
  slots under the H3 task title without breaking the report outline.

Public API
----------
* :func:`generate_report_markdown` — assemble the full Markdown report.
* :func:`shift_markdown_headers`  — shift H1-H6 levels down by N (capped at 6).
* :func:`generate_anchors`        — github-slugger-compatible anchor map.
* :func:`status_emoji`            — status enum value → emoji.
* :func:`slugify_github`          — single-string slug helper (no duplicates).

The status-emoji table mirrors :mod:`securagentx.flows.models`:
``📝 created, ⚡ running, ✅ finished, ❌ failed, ⏳ waiting``.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Iterable, Protocol, runtime_checkable

logger = logging.getLogger("securagentx.reports.markdown")


# ---------------------------------------------------------------------------
# Status emoji mapping — mirrors PentAGI's getStatusEmoji().
# ---------------------------------------------------------------------------

#: Status value → emoji glyph. Keys accept either the raw enum *value*
#: (``"created"``) or the enum instance itself (via :func:`status_emoji`).
_STATUS_EMOJI: dict[str, str] = {
    "created": "\U0001F4DD",   # 📝
    "running": "\u26A1",       # ⚡
    "finished": "\u2705",      # ✅
    "failed": "\u274C",        # ❌
    "waiting": "\u23F3",       # ⏳
}

#: Default emoji for unknown / missing status values.
DEFAULT_STATUS_EMOJI: str = "\U0001F4DD"  # 📝


def status_emoji(status: Any) -> str:
    """Return the emoji glyph for a flow/task/subtask status value.

    Accepts either the canonical lowercase string (``"created"``,
    ``"running"``, ``"finished"``, ``"failed"``, ``"waiting"``) or any
    enum whose ``.value`` is one of those strings (e.g.
    :class:`securagentx.flows.models.FlowStatus`). Unknown values fall back
    to :data:`DEFAULT_STATUS_EMOJI`.
    """
    if status is None:
        return DEFAULT_STATUS_EMOJI
    # Enum instances expose .value; raw strings just are their value.
    raw = getattr(status, "value", status)
    if not isinstance(raw, str):
        return DEFAULT_STATUS_EMOJI
    return _STATUS_EMOJI.get(raw.lower(), DEFAULT_STATUS_EMOJI)


# ---------------------------------------------------------------------------
# GitHub-slugger-compatible slug generation.
# ---------------------------------------------------------------------------

# The github-slugger algorithm (v1.x — what rehype-slug / PentAGI uses):
#   1. lowercase + trim
#   2. drop characters not in [\w\- ]   (ASCII \w — matches JS without `u` flag)
#   3. replace whitespace with hyphens
#   4. collapse runs of hyphens
# We use re.ASCII so \w is [A-Za-z0-9_] (JS semantics without `u` flag).

_NON_SLUG_CHARS_RE = re.compile(r"[^\w\- ]+", re.ASCII)
_WHITESPACE_RE = re.compile(r"\s+")
_HYPHEN_RUN_RE = re.compile(r"-+")


def slugify_github(text: str) -> str:
    """Return a github-slugger-compatible slug for a single string.

    Mirrors the algorithm in PentAGI's ``github-slugger`` dependency so
    that the anchor IDs produced here match what ``rehype-slug`` would
    emit for the same heading text in the rendered HTML view. Emoji
    glyphs are *not* word characters and are therefore dropped, which is
    exactly the behaviour PentAGI relies on (the emoji remains in the
    visible heading text but the anchor is purely alphanumeric).
    """
    if not text:
        return ""
    slug = text.lower().strip()
    slug = _NON_SLUG_CHARS_RE.sub("", slug)
    slug = _WHITESPACE_RE.sub("-", slug)
    slug = _HYPHEN_RUN_RE.sub("-", slug)
    # Trim leading/trailing hyphens that may result from leading/trailing
    # non-word characters (e.g. a leading emoji + space).
    return slug.strip("-")


def generate_anchors(headings: Iterable[str]) -> dict[str, str]:
    """Generate github-slugger-compatible anchors for a list of headings.

    Returns a mapping ``{heading_text: anchor_id}``. Duplicate slugs are
    disambiguated with a ``-1``, ``-2`` suffix, matching the
    ``github-slugger`` duplicate-handling semantics (the *first*
    occurrence gets no suffix; subsequent ones get -1, -2, …).
    """
    seen: dict[str, int] = {}
    result: dict[str, str] = {}
    for heading in headings:
        base = slugify_github(heading)
        if not base:
            # All-non-word heading — fall back to a stable placeholder.
            base = "section"
        slug = base
        count = seen.get(base, 0)
        if count > 0:
            slug = f"{base}-{count}"
        seen[base] = count + 1
        result[heading] = slug
    return result


# ---------------------------------------------------------------------------
# Markdown header shifting — used to slot task.input under the H3 task title.
# ---------------------------------------------------------------------------

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)


def shift_markdown_headers(text: str, levels: int = 3) -> str:
    """Shift all Markdown ATX headings down by ``levels`` (capped at H6).

    Mirrors PentAGI's ``shiftMarkdownHeaders``: every ``#``-prefixed line
    has its leading hashes extended by ``levels`` characters, but never
    beyond six. Lines starting with 6 hashes already are left at 6.
    A heading inside a fenced code block (``` ``` ```) is *not* exempted
    by the original implementation; we match that behaviour exactly so
    the output stays byte-identical to the upstream TypeScript.
    """
    if not text:
        return text

    def _replace(match: re.Match[str]) -> str:
        hashes = match.group(1)
        content = match.group(2)
        new_level = min(len(hashes) + levels, 6)
        return f"{'#' * new_level} {content}"

    return _HEADING_RE.sub(_replace, text)


# ---------------------------------------------------------------------------
# Duck-typed protocols — accept either Pydantic models or simple dataclasses.
# ---------------------------------------------------------------------------


@runtime_checkable
class _FlowLike(Protocol):
    """Subset of :class:`securagentx.flows.models.Flow` we consume."""

    id: int
    title: str

    @property
    def status(self) -> Any:  # noqa: D401 — Protocol property
        """Lifecycle status (string or enum with .value)."""


@runtime_checkable
class _TaskLike(Protocol):
    """Subset of :class:`securagentx.flows.models.Task` we consume."""

    id: int
    title: str
    input: str
    result: str

    @property
    def status(self) -> Any:  # noqa: D401 — Protocol property
        """Lifecycle status (string or enum with .value)."""


@runtime_checkable
class _SubtaskLike(Protocol):
    """Subset of :class:`securagentx.flows.models.Subtask` we consume."""

    id: int
    title: str
    description: str
    result: str
    task_id: int

    @property
    def status(self) -> Any:  # noqa: D401 — Protocol property
        """Lifecycle status (string or enum with .value)."""


# ---------------------------------------------------------------------------
# Report assembly.
# ---------------------------------------------------------------------------


def _heading_text(emoji: str, num: int | str, title: str) -> str:
    """Build the visible heading text: ``{emoji} {num}. {title}``."""
    return f"{emoji} {num}. {title}"


def _group_subtasks_by_task(
    subtasks: Iterable[_SubtaskLike] | None,
) -> dict[int, list[_SubtaskLike]]:
    """Group a flat list of subtasks by their ``task_id`` field.

    Subtasks are sorted by ``id`` within each group so the rendered order
    matches PentAGI's `[...task.subtasks].sort((a, b) => +a.id - +b.id)`.
    """
    grouped: dict[int, list[_SubtaskLike]] = {}
    if not subtasks:
        return grouped
    for st in subtasks:
        grouped.setdefault(int(st.task_id), []).append(st)
    for task_id in grouped:
        grouped[task_id].sort(key=lambda s: int(s.id))
    return grouped


def _generate_toc(
    flow: _FlowLike | None,
    tasks: list[_TaskLike],
    subtasks_by_task: dict[int, list[_SubtaskLike]],
) -> str:
    """Build the TOC section (flow title H1 + nested task/subtask links).

    Anchor IDs come from :func:`slugify_github` applied to the visible
    heading text *including emoji* — exactly as the original PentAGI
    code does, so the same anchor appears in both the TOC links and the
    rendered H3/H4 headings.
    """
    lines: list[str] = []

    if flow is not None:
        flow_emoji = status_emoji(flow.status)
        lines.append(f"# {flow_emoji} {flow.id}. {flow.title}")
        lines.append("")
        lines.append("## Table of Contents")

    if not tasks:
        if flow is not None:
            lines.append("")
            lines.append("No tasks available for this flow.")
            lines.append("")
            lines.append("---")
            lines.append("")
        return "\n".join(lines)

    for task in tasks:
        task_emoji = status_emoji(task.status)
        task_text = _heading_text(task_emoji, task.id, task.title)
        task_anchor = slugify_github(task_text)
        lines.append(f"- [{task_text}](#{task_anchor})")

        for subtask in subtasks_by_task.get(int(task.id), []):
            sub_emoji = status_emoji(subtask.status)
            sub_text = _heading_text(sub_emoji, subtask.id, subtask.title)
            sub_anchor = slugify_github(sub_text)
            lines.append(f"  - [{sub_text}](#{sub_anchor})")

    lines.append("")
    lines.append("---")
    lines.append("")
    return "\n".join(lines)


def generate_report_markdown(
    flow: _FlowLike | None,
    tasks: Iterable[_TaskLike] | None,
    subtasks: Iterable[_SubtaskLike] | None = None,
) -> str:
    """Assemble the full Markdown report for a flow + its tasks + subtasks.

    Layout mirrors PentAGI's :func:`generateReport`:

    .. code-block:: markdown

        # {flow_emoji} {flow_id}. {flow_title}

        ## Table of Contents
        - [✅ 1. Task title](#1-task-title)
          - [⚡ 1.1. Subtask title](#11-subtask-title)

        ---

        ### {task_emoji} {task_id}. {task_title}
        {shifted_task_input}
        ---
        {task_result}

        #### {subtask_emoji} {subtask_id}. {subtask_title}
        {subtask_description}
        ---
        {subtask_result}

    Tasks are sorted by ``id`` ascending; subtasks within each task are
    grouped by ``task_id`` and sorted by ``id``. Empty inputs / results
    are skipped (matching the upstream ``?.trim()`` guard). Adjacent task
    sections are separated by an ``---`` horizontal rule.
    """
    # Materialise and sort tasks.
    task_list: list[_TaskLike] = list(tasks) if tasks else []
    task_list.sort(key=lambda t: int(t.id))

    subtask_list: list[_SubtaskLike] = list(subtasks) if subtasks else []
    subtasks_by_task = _group_subtasks_by_task(subtask_list)

    # Empty-flow short-circuit — matches PentAGI's `if (!tasks || length===0)`.
    if not task_list:
        if flow is not None:
            flow_emoji = status_emoji(flow.status)
            return (
                f"# {flow_emoji} {flow.id}. {flow.title}\n\n"
                "No tasks available for this flow."
            )
        return "No tasks available for this flow."

    out: list[str] = [_generate_toc(flow, task_list, subtasks_by_task)]

    for task_idx, task in enumerate(task_list):
        task_emoji = status_emoji(task.status)
        out.append(f"### {_heading_text(task_emoji, task.id, task.title)}")
        out.append("")

        # Task input — shift headers down by 3 so H1/H2 inside the input
        # don't override the H3 task title in the report outline.
        task_input = getattr(task, "input", "") or ""
        if task_input.strip():
            out.append(shift_markdown_headers(task_input, 3))
            out.append("")

        task_result = getattr(task, "result", "") or ""
        if task_result.strip():
            out.append("---")
            out.append("")
            out.append(task_result)
            out.append("")

        for subtask in subtasks_by_task.get(int(task.id), []):
            sub_emoji = status_emoji(subtask.status)
            out.append(f"#### {_heading_text(sub_emoji, subtask.id, subtask.title)}")
            out.append("")

            sub_desc = getattr(subtask, "description", "") or ""
            if sub_desc.strip():
                out.append(sub_desc)
                out.append("")

            sub_result = getattr(subtask, "result", "") or ""
            if sub_result.strip():
                out.append("---")
                out.append("")
                out.append(sub_result)
                out.append("")

        # Inter-task separator (matches PentAGI: no trailing separator
        # after the LAST task).
        if task_idx < len(task_list) - 1:
            out.append("---")
            out.append("")

    return "\n".join(out).strip()


__all__ = [
    "DEFAULT_STATUS_EMOJI",
    "status_emoji",
    "slugify_github",
    "generate_anchors",
    "shift_markdown_headers",
    "generate_report_markdown",
]
