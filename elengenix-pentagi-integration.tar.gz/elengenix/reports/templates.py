"""securagentx/reports/templates.py — Markdown report templates.

This module provides structured Markdown templates for the four canonical
report types emitted by SecurAgentX's reporter pipeline:

* :data:`VULNERABILITY_TEMPLATE`     — per-finding technical report
  (CVE / severity / vector / PoC / evidence / impact / remediation /
  references). Used by the bug-bounty reporter and the vuln-hunter
  post-processor.
* :data:`EXECUTIVE_SUMMARY_TEMPLATE` — management-facing summary
  (scope, findings count by severity, business risk, top remediation
  priorities). One page, no technical jargon.
* :data:`TECHNICAL_REPORT_TEMPLATE`  — engineer-facing deep-dive
  (recon methodology, attack surface, exploit chain walkthroughs,
  raw command output, fix recommendations).
* :data:`COMPLIANCE_REPORT_TEMPLATE` — auditor-facing mapping
  (PCI-DSS / SOC2 / ISO27001 control coverage + gap analysis).

Each template is a Python ``str.format`` template — call
``template.format(**fields)`` to instantiate. Missing fields render as
the literal placeholder text (e.g. ``{cve_id}``) so reviewers can spot
unfilled sections at a glance. The :func:`render_template` helper
substitutes empty strings for missing keys instead.

All templates use plain Markdown (no Jinja2) so they can be rendered by
the lightweight :mod:`securagentx.reports.pdf` renderer without an extra
dependency.
"""

from __future__ import annotations

import logging
from typing import Any, Mapping

logger = logging.getLogger("securagentx.reports.templates")


# ---------------------------------------------------------------------------
# Vulnerability finding template — per-finding technical write-up.
# ---------------------------------------------------------------------------

VULNERABILITY_TEMPLATE: str = """## {cve_id}

**Severity:** {severity} (CVSS: {cvss_score})
**Vector:** {cvss_vector}
**Affected Component:** {affected_component}

### Description

{description}

### Proof of Concept

```bash
{exploitation_commands}
```

### Evidence

{evidence}

### Impact

{impact}

### Remediation

1. {immediate_fix}
2. {long_term_fix}
3. {compensating_controls}

### References

- {cve_url}
- {vendor_advisory}
- {owasp_reference}
"""


# ---------------------------------------------------------------------------
# Executive summary template — management-facing one-pager.
# ---------------------------------------------------------------------------

EXECUTIVE_SUMMARY_TEMPLATE: str = """# Executive Summary — {engagement_name}

**Prepared for:** {client_name}
**Prepared by:** {analyst_name}
**Date:** {report_date}
**Engagement window:** {start_date} – {end_date}

## 1. Scope

{scope_summary}

## 2. Overall Risk Posture

{overall_risk_posture}

## 3. Findings Summary

| Severity | Count |
|----------|-------|
| Critical | {critical_count} |
| High     | {high_count} |
| Medium   | {medium_count} |
| Low      | {low_count} |
| Info     | {info_count} |

**Total findings:** {total_findings}

## 4. Top Business Risks

{top_business_risks}

## 5. Recommended Next Steps

1. {next_step_1}
2. {next_step_2}
3. {next_step_3}

## 6. Conclusion

{conclusion}
"""


# ---------------------------------------------------------------------------
# Technical report template — engineer-facing deep-dive.
# ---------------------------------------------------------------------------

TECHNICAL_REPORT_TEMPLATE: str = """# Technical Assessment Report — {engagement_name}

**Prepared for:** {client_name}
**Prepared by:** {analyst_name}
**Date:** {report_date}

## 1. Engagement Overview

{overview}

### 1.1 Scope

{scope_details}

### 1.2 Methodology

{methodology}

### 1.3 Tools Used

{tools_used}

## 2. Reconnaissance & Attack Surface

{recon_summary}

### 2.1 Hosts and Services

{hosts_services}

### 2.2 Web Application Endpoints

{web_endpoints}

### 2.3 Authentication Surface

{auth_surface}

## 3. Findings

{findings_summary}

### 3.1 Critical Findings

{critical_findings_detail}

### 3.2 High Findings

{high_findings_detail}

### 3.3 Medium / Low / Info Findings

{medium_low_info_detail}

## 4. Exploit Chain Walkthroughs

{exploit_chains}

## 5. Remediation Roadmap

### 5.1 Immediate (≤ 7 days)

{immediate_remediation}

### 5.2 Short-term (≤ 30 days)

{short_term_remediation}

### 5.3 Long-term (≤ 90 days)

{long_term_remediation}

## 6. Appendices

### Appendix A — Raw Tool Output

{appendix_raw_output}

### Appendix B — Request / Response Logs

{appendix_request_logs}

### Appendix C — Screenshots

{appendix_screenshots}
"""


# ---------------------------------------------------------------------------
# Compliance report template — auditor-facing control mapping.
# ---------------------------------------------------------------------------

COMPLIANCE_REPORT_TEMPLATE: str = """# Compliance Mapping Report — {engagement_name}

**Prepared for:** {client_name}
**Prepared by:** {analyst_name}
**Date:** {report_date}
**Frameworks covered:** {frameworks}

## 1. Executive Summary

{executive_summary}

## 2. PCI-DSS v4.0 Mapping

| PCI-DSS Requirement | Status | Evidence | Gap |
|---------------------|--------|----------|-----|
{pci_dss_table}

### 2.1 PCI-DSS Gaps

{pci_dss_gaps}

## 3. SOC 2 (TSC 2017) Mapping

| Trust Service Criteria | Status | Evidence | Gap |
|------------------------|--------|----------|-----|
{soc2_table}

### 3.1 SOC 2 Gaps

{soc2_gaps}

## 4. ISO/IEC 27001:2022 Mapping

| ISO 27001 Control | Status | Evidence | Gap |
|-------------------|--------|----------|-----|
{iso27001_table}

### 4.1 ISO 27001 Gaps

{iso27001_gaps}

## 5. Cross-Framework Coverage Matrix

{cross_framework_matrix}

## 6. Remediation Plan

### 6.1 Critical Gaps (≤ 30 days)

{critical_gaps_remediation}

### 6.2 High Gaps (≤ 60 days)

{high_gaps_remediation}

### 6.3 Medium Gaps (≤ 90 days)

{medium_gaps_remediation}

## 7. Attestation

{attestation_statement}

**Signed:**

{analyst_name}
{analyst_title}
{report_date}
"""


# ---------------------------------------------------------------------------
# Convenience helpers.
# ---------------------------------------------------------------------------


def render_template(template: str, fields: Mapping[str, Any]) -> str:
    """Render a ``str.format`` template, substituting ``""`` for missing keys.

    Python's ``str.format`` raises :class:`KeyError` if a placeholder is
    missing from the ``fields`` mapping. For report templates that is
    rarely the desired behaviour — partial templates are common during
    incremental report building. This helper fills missing keys with
    empty strings (so the placeholder vanishes) and logs a debug message
    listing which keys were missing.
    """
    # Collect all placeholder names referenced by the template.
    try:
        from string import Formatter

        referenced = {
            fname
            for _, fname, _, _ in Formatter().parse(template)
            if fname
        }
    except Exception:
        referenced = set()

    missing = referenced - set(fields.keys())
    if missing:
        logger.debug(
            "Template references %d missing field(s); substituting empty "
            "strings: %s",
            len(missing),
            sorted(missing),
        )
    safe_fields = {name: "" for name in missing}
    safe_fields.update(fields)
    return template.format(**safe_fields)


#: Mapping of template name → template body, used by the export module
#: to look up templates by string identifier.
TEMPLATES: dict[str, str] = {
    "vulnerability": VULNERABILITY_TEMPLATE,
    "executive_summary": EXECUTIVE_SUMMARY_TEMPLATE,
    "technical_report": TECHNICAL_REPORT_TEMPLATE,
    "compliance_report": COMPLIANCE_REPORT_TEMPLATE,
}


def get_template(name: str) -> str:
    """Return the template body for ``name``.

    Raises :class:`KeyError` if the name is not in :data:`TEMPLATES`.
    """
    if name not in TEMPLATES:
        raise KeyError(
            f"Unknown template {name!r}; available: {sorted(TEMPLATES)}"
        )
    return TEMPLATES[name]


__all__ = [
    "VULNERABILITY_TEMPLATE",
    "EXECUTIVE_SUMMARY_TEMPLATE",
    "TECHNICAL_REPORT_TEMPLATE",
    "COMPLIANCE_REPORT_TEMPLATE",
    "TEMPLATES",
    "get_template",
    "render_template",
]
