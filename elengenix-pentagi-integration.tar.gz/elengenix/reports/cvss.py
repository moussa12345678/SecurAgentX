"""securagentx/reports/cvss.py — CVSS v3.1 base-score calculator.

This module ports PentAGI's mental model of CVSS (the Go upstream had no
in-tree calculator; the frontend rendered vector strings emitted by the
reporter LLM). Here we provide a strict, spec-compliant implementation of
the CVSS v3.1 *base* score so reports can compute a numeric score and
severity label from any vector the LLM emits, without depending on an
external service.

The implementation follows the CVSS v3.1 specification document
(https://www.first.org/cvss/v3.1/specification-document) exactly:

* Metric weights are hard-coded constants from §7.1 / §7.2.
* The Impact Sub-Score (ISC) formula differs by Scope (§7.2.1).
* Privileges-Required weight depends on Scope (§7.2.2).
* The base score uses the Roundup function defined in §7.3.

Public API
----------
* :class:`CVSSVector` — Pydantic model for the 8 base metrics.
* :class:`CVSSResult`  — Pydantic model carrying the computed score + subscores.
* :func:`calculate_cvss_score` — compute the numeric base score (0.0 - 10.0).
* :func:`cvss_severity` — string label (None/Info/Low/Medium/High/Critical).
* :func:`cvss_result` — full breakdown (score, severity, subscores, vector string).
* :func:`parse_cvss_vector` — parse a ``CVSS:3.1/AV:N/...`` string.
* :func:`format_cvss_vector` — emit a canonical ``CVSS:3.1/...`` string.

All functions are pure and synchronous; the heavy lifting is float math.
"""

from __future__ import annotations

import logging
import math
import re
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

logger = logging.getLogger("securagentx.reports.cvss")


# ---------------------------------------------------------------------------
# Metric enums — keep the canonical single-letter values from the spec.
# ---------------------------------------------------------------------------


class AttackVector(str, Enum):
    """Reflects the context by which vulnerability exploitation is possible."""

    NETWORK = "N"
    ADJACENT = "A"
    LOCAL = "L"
    PHYSICAL = "P"


class AttackComplexity(str, Enum):
    """Describes the conditions beyond the attacker's control that must exist."""

    LOW = "L"
    HIGH = "H"


class PrivilegesRequired(str, Enum):
    """Level of privileges an attacker must possess before exploiting the vuln."""

    NONE = "N"
    LOW = "L"
    HIGH = "H"


class UserInteraction(str, Enum):
    """Whether user participation is required beyond the attacker."""

    NONE = "N"
    REQUIRED = "R"


class Scope(str, Enum):
    """Whether a vulnerability can affect resources beyond the security authority."""

    UNCHANGED = "U"
    CHANGED = "C"


class CIAImpact(str, Enum):
    """Impact (Confidentiality / Integrity / Availability) severity level."""

    NONE = "N"
    LOW = "L"
    HIGH = "H"


# ---------------------------------------------------------------------------
# Spec-derived constant lookup tables (CVSS v3.1 §7.1, §7.2).
# ---------------------------------------------------------------------------

# Exploitability metric values (Table 23 / 24 / 25 / 26).
_AV_WEIGHTS: dict[str, float] = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20}
_AC_WEIGHTS: dict[str, float] = {"L": 0.77, "H": 0.44}
_UI_WEIGHTS: dict[str, float] = {"N": 0.85, "R": 0.62}

# PR weight depends on Scope (Table 25). Two tables: U → unchanged, C → changed.
_PR_WEIGHTS_UNCHANGED: dict[str, float] = {"N": 0.85, "L": 0.62, "H": 0.27}
_PR_WEIGHTS_CHANGED: dict[str, float] = {"N": 0.85, "L": 0.68, "H": 0.50}

# Impact Sub-Score (ISC) weights for C / I / A (Table 22).
_CIA_WEIGHTS: dict[str, float] = {"N": 0.00, "L": 0.22, "H": 0.56}

# String → enum lookups used by parse_cvss_vector.
_METRIC_ENUMS: dict[str, type[Enum]] = {
    "AV": AttackVector,
    "AC": AttackComplexity,
    "PR": PrivilegesRequired,
    "UI": UserInteraction,
    "S": Scope,
    "C": CIAImpact,
    "I": CIAImpact,
    "A": CIAImpact,
}

# Pydantic-friendly string → enum value mapping (for the model validator below).
_ALLOWED_VALUES: dict[str, set[str]] = {
    "attack_vector": {e.value for e in AttackVector},
    "attack_complexity": {e.value for e in AttackComplexity},
    "privileges_required": {e.value for e in PrivilegesRequired},
    "user_interaction": {e.value for e in UserInteraction},
    "scope": {e.value for e in Scope},
    "confidentiality_impact": {e.value for e in CIAImpact},
    "integrity_impact": {e.value for e in CIAImpact},
    "availability_impact": {e.value for e in CIAImpact},
}


# ---------------------------------------------------------------------------
# Pydantic models.
# ---------------------------------------------------------------------------


class CVSSVector(BaseModel):
    """Pydantic model for the 8 CVSS v3.1 base metrics.

    Each field stores the canonical single-letter value (e.g. ``"N"`` for
    Network attack vector). The model accepts either a plain string or
    the matching enum; both are normalised to the single-letter string.
    """

    model_config = ConfigDict(use_enum_values=False, extra="forbid")

    attack_vector: AttackVector = Field(
        default=AttackVector.NETWORK,
        description="Network (N), Adjacent (A), Local (L), Physical (P).",
    )
    attack_complexity: AttackComplexity = Field(
        default=AttackComplexity.LOW,
        description="Low (L) or High (H).",
    )
    privileges_required: PrivilegesRequired = Field(
        default=PrivilegesRequired.NONE,
        description="None (N), Low (L), High (H).",
    )
    user_interaction: UserInteraction = Field(
        default=UserInteraction.NONE,
        description="None (N) or Required (R).",
    )
    scope: Scope = Field(
        default=Scope.UNCHANGED,
        description="Unchanged (U) or Changed (C).",
    )
    confidentiality_impact: CIAImpact = Field(
        default=CIAImpact.NONE,
        description="None (N), Low (L), High (H).",
    )
    integrity_impact: CIAImpact = Field(
        default=CIAImpact.NONE,
        description="None (N), Low (L), High (H).",
    )
    availability_impact: CIAImpact = Field(
        default=CIAImpact.NONE,
        description="None (N), Low (L), High (H).",
    )

    # --- validators: accept plain string values -----------------------------

    @field_validator(
        "attack_vector",
        "attack_complexity",
        "privileges_required",
        "user_interaction",
        "scope",
        "confidentiality_impact",
        "integrity_impact",
        "availability_impact",
        mode="before",
    )
    @classmethod
    def _coerce_enum(cls, v: Any) -> Any:
        """Accept either the single-letter string or the enum instance."""
        if isinstance(v, Enum):
            return v
        if isinstance(v, str):
            # Validate against the union of all metric values; the field's
            # own enum type will narrow it further at instantiation time.
            up = v.strip().upper()
            return up
        return v


class CVSSResult(BaseModel):
    """Full CVSS v3.1 base-score breakdown for a vector."""

    model_config = ConfigDict(extra="forbid")

    vector: CVSSVector
    base_score: float
    severity: str
    impact_subscore: float
    exploitability_subscore: float
    vector_string: str


# ---------------------------------------------------------------------------
# Core scoring functions.
# ---------------------------------------------------------------------------


def _roundup(value: float) -> float:
    """CVSS v3.1 ``Roundup`` function (spec §7.3.1).

    The spec mandates a specific rounding: multiply by 100000, ceil to the
    nearest integer, divide by 100000, then ceil to one decimal place.
    Using Python's ``round()`` would yield wrong values for some vectors
    (e.g. 4.02 → 4.0 with round-half-to-even, but spec says 4.1).
    """
    if value < 0:
        return 0.0
    intermediate = math.ceil(value * 100000) / 100000.0
    return math.ceil(intermediate * 10) / 10.0


def _metric_value(model_value: Any) -> str:
    """Return the single-letter value for a metric field (enum or str)."""
    if isinstance(model_value, Enum):
        return model_value.value
    return str(model_value).upper()


def calculate_cvss_score(vector: CVSSVector) -> float:
    """Compute the CVSS v3.1 base score (0.0 - 10.0) for a vector.

    Implements the formula from spec §7.2.1 — ISC depends on Scope, and
    the Privileges-Required weight is doubled for Changed scope. The
    base score is then rounded up via the canonical ``Roundup`` function
    (see :func:`_roundup`).
    """
    av = _metric_value(vector.attack_vector)
    ac = _metric_value(vector.attack_complexity)
    pr = _metric_value(vector.privileges_required)
    ui = _metric_value(vector.user_interaction)
    s = _metric_value(vector.scope)
    c = _metric_value(vector.confidentiality_impact)
    i = _metric_value(vector.integrity_impact)
    a = _metric_value(vector.availability_impact)

    # Impact Sub-Score (ISC) base.
    isc_base = 1 - (
        (1 - _CIA_WEIGHTS[c])
        * (1 - _CIA_WEIGHTS[i])
        * (1 - _CIA_WEIGHTS[a])
    )

    # Scope-dependent ISC formula.
    if s == "U":
        impact = 6.42 * isc_base
        pr_weight = _PR_WEIGHTS_UNCHANGED[pr]
    else:
        impact = 7.52 * (isc_base - 0.029) - 3.25 * (isc_base - 0.02) ** 15
        pr_weight = _PR_WEIGHTS_CHANGED[pr]

    # Exploitability Sub-Score.
    exploitability = (
        8.22
        * _AV_WEIGHTS[av]
        * _AC_WEIGHTS[ac]
        * pr_weight
        * _UI_WEIGHTS[ui]
    )

    # Base Score (scope-dependent multiplier).
    if impact <= 0:
        base_score = 0.0
    elif s == "U":
        base_score = min(impact + exploitability, 10.0)
    else:
        base_score = min(1.08 * (impact + exploitability), 10.0)

    return _roundup(base_score)


def _impact_subscore(vector: CVSSVector) -> float:
    """Return the unrounded Impact Sub-Score (for breakdown display)."""
    c = _metric_value(vector.confidentiality_impact)
    i = _metric_value(vector.integrity_impact)
    a = _metric_value(vector.availability_impact)
    s = _metric_value(vector.scope)

    isc_base = 1 - (
        (1 - _CIA_WEIGHTS[c])
        * (1 - _CIA_WEIGHTS[i])
        * (1 - _CIA_WEIGHTS[a])
    )
    if s == "U":
        return 6.42 * isc_base
    return 7.52 * (isc_base - 0.029) - 3.25 * (isc_base - 0.02) ** 15


def _exploitability_subscore(vector: CVSSVector) -> float:
    """Return the unrounded Exploitability Sub-Score (for breakdown display)."""
    av = _metric_value(vector.attack_vector)
    ac = _metric_value(vector.attack_complexity)
    pr = _metric_value(vector.privileges_required)
    ui = _metric_value(vector.user_interaction)
    s = _metric_value(vector.scope)

    pr_weight = (
        _PR_WEIGHTS_UNCHANGED[pr] if s == "U" else _PR_WEIGHTS_CHANGED[pr]
    )
    return (
        8.22
        * _AV_WEIGHTS[av]
        * _AC_WEIGHTS[ac]
        * pr_weight
        * _UI_WEIGHTS[ui]
    )


def cvss_severity(score: float) -> str:
    """Return the CVSS v3.1 severity label for a base score.

    Thresholds (spec §7.4, Table 14):

    * 0.0         → "None"
    * 0.1 - 3.9   → "Low"
    * 4.0 - 6.9   → "Medium"
    * 7.0 - 8.9   → "High"
    * 9.0 - 10.0  → "Critical"

    A score of exactly 0.0 is mapped to ``"Info"`` for report-rendering
    purposes (the spec calls this "None" but PentAGI / most pentest tools
    render it as "Info" or "Informational").
    """
    if score <= 0.0:
        return "Info"
    if score < 4.0:
        return "Low"
    if score < 7.0:
        return "Medium"
    if score < 9.0:
        return "High"
    return "Critical"


def cvss_result(vector: CVSSVector) -> CVSSResult:
    """Compute the full CVSSResult breakdown (score, severity, subscores)."""
    score = calculate_cvss_score(vector)
    return CVSSResult(
        vector=vector,
        base_score=score,
        severity=cvss_severity(score),
        impact_subscore=round(_impact_subscore(vector), 1),
        exploitability_subscore=round(_exploitability_subscore(vector), 1),
        vector_string=format_cvss_vector(vector),
    )


# ---------------------------------------------------------------------------
# Vector-string parsing / formatting.
# ---------------------------------------------------------------------------


_VECTOR_PART_RE = re.compile(r"^([A-Z]+):([A-Za-z]+)$")


def parse_cvss_vector(string: str) -> CVSSVector:
    """Parse a ``CVSS:3.1/AV:N/AC:L/...`` vector string into a CVSSVector.

    Accepts both prefixed (``CVSS:3.1/...``) and bare (``AV:N/AC:L/...``)
    forms. Unknown metrics are ignored with a warning; metric values not
    in the spec raise :class:`ValueError`.
    """
    if not isinstance(string, str) or not string.strip():
        raise ValueError("CVSS vector string is empty")

    text = string.strip()

    # Strip the optional "CVSS:3.1/" or "CVSS:3.0/" prefix.
    if text.upper().startswith("CVSS:"):
        # Split on the first '/' to drop the prefix portion.
        prefix, _, rest = text.partition("/")
        if not rest:
            raise ValueError(f"CVSS vector string missing metrics: {string!r}")
        text = rest

    parts: dict[str, str] = {}
    for token in text.split("/"):
        token = token.strip()
        if not token:
            continue
        match = _VECTOR_PART_RE.match(token)
        if not match:
            logger.warning("Ignoring unparseable CVSS metric token: %r", token)
            continue
        key = match.group(1).upper()
        val = match.group(2).upper()
        parts[key] = val

    if not parts:
        raise ValueError(f"CVSS vector string contains no metrics: {string!r}")

    # Map to model field names. The metric→field table mirrors the spec.
    field_for_metric: dict[str, str] = {
        "AV": "attack_vector",
        "AC": "attack_complexity",
        "PR": "privileges_required",
        "UI": "user_interaction",
        "S": "scope",
        "C": "confidentiality_impact",
        "I": "integrity_impact",
        "A": "availability_impact",
    }

    kwargs: dict[str, Any] = {}
    for metric, value in parts.items():
        if metric not in field_for_metric:
            logger.warning("Ignoring unknown CVSS metric: %s", metric)
            continue
        enum_cls = _METRIC_ENUMS[metric]
        try:
            enum_cls(value)
        except ValueError as exc:
            raise ValueError(
                f"Invalid value {value!r} for CVSS metric {metric}"
            ) from exc
        kwargs[field_for_metric[metric]] = value

    return CVSSVector(**kwargs)


def format_cvss_vector(vector: CVSSVector) -> str:
    """Emit a canonical ``CVSS:3.1/AV:N/AC:L/...`` vector string."""
    return (
        "CVSS:3.1/"
        f"AV:{_metric_value(vector.attack_vector)}/"
        f"AC:{_metric_value(vector.attack_complexity)}/"
        f"PR:{_metric_value(vector.privileges_required)}/"
        f"UI:{_metric_value(vector.user_interaction)}/"
        f"S:{_metric_value(vector.scope)}/"
        f"C:{_metric_value(vector.confidentiality_impact)}/"
        f"I:{_metric_value(vector.integrity_impact)}/"
        f"A:{_metric_value(vector.availability_impact)}"
    )


__all__ = [
    "AttackVector",
    "AttackComplexity",
    "PrivilegesRequired",
    "UserInteraction",
    "Scope",
    "CIAImpact",
    "CVSSVector",
    "CVSSResult",
    "calculate_cvss_score",
    "cvss_severity",
    "cvss_result",
    "parse_cvss_vector",
    "format_cvss_vector",
]
